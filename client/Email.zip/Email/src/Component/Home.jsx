import React, { useState } from 'react';
import * as XLSX from 'xlsx';

const Home = () => {
    const [inputs, setInputs] = useState({
        companyTitle: '',
        content: '',
        pdf: null,
        video: null,
        image: null,
    });
    const handleChange = (e) => {
        const { name, value, files } = e.target;
        if (files) {
            setInputs(prev => ({ ...prev, [name]: files[0] }));
        } else {
            setInputs(prev => ({ ...prev, [name]: value }));
        }
    };
    const [tableData, setTableData] = useState([]);

    const handleFileUpload = (event) => {
        const file = event.target.files[0];
        const reader = new FileReader();
        reader.onload = (e) => {
            const binaryStr = e.target.result;
            const workbook = XLSX.read(binaryStr, { type: 'binary' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet);
            setTableData(jsonData);
        };
        reader.readAsBinaryString(file);
    };

    return (
        <div className='bg-white  mx-5 border-2 border-rose-100 p-6'>
            <div className='space-y-4'>
                <div>
                    <label htmlFor="company-title" className="block text-sm font-medium text-gray-700">Company Title</label>
                    <input type="text" name="companyTitle" id="company-title" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm" placeholder="Enter company title" value={inputs.companyTitle} onChange={handleChange} />
                </div>

                <div>
                    <label htmlFor="content" className="block text-sm font-medium text-gray-700">Message</label>
                    <textarea id="content" name="content" rows="3" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm" placeholder="Enter your message" value={inputs.content} onChange={handleChange}></textarea>
                </div>

                {/* Upload Buttons */}
                <div className='flex justify-around'>
                    <label className="flex items-center p-2 border rounded cursor-pointer">
                        <span>Upload PDF</span>
                        <input type="file" name="pdf" className="hidden" accept="application/pdf" onChange={handleChange} />
                    </label>
                    <label className="flex items-center p-2 border rounded cursor-pointer">
                        <span>Upload Video</span>
                        <input type="file" name="video" className="hidden" accept="video/*" onChange={handleChange} />
                    </label>
                    <label className="flex items-center p-2 border rounded cursor-pointer">
                        <span>Upload Image</span>
                        <input type="file" name="image" className="hidden" accept="image/*" onChange={handleChange} />
                    </label>
                    <label className="flex items-center p-2 border rounded cursor-pointer">
                        <span>Upload Excel file</span>
                        <input type="file" onChange={handleFileUpload} className="hidden" accept=".xlsx, .xls" />
                    </label>
                </div>
                {/* Data Display Section */}
                {tableData.length > 0 && (
                    <div className='mt-4  border rounded h-[600px] overflow-scroll'>
                        <table className='min-w-full'>
                            <thead>
                                <tr>
                                    {Object.keys(tableData[0]).map((key) => (
                                        <th key={key} className='px-4 py-2 border'>{key}</th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {tableData.map((row, index) => (
                                    <tr key={index}>
                                        {Object.values(row).map((val, idx) => (
                                            <td key={idx} className='px-4 py-2 border'>{val}</td>
                                        ))}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    )
}

export default Home